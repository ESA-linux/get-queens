---
name: Custom issue template
about: Describe this issue template's purpose here.
title: "⚖️⚡️⚡️✨࿈Magོic࿇Spell࿈✨\U0001FA78\U0001F525 ever།༄ ༴࿇གོཇངཉསདབ ཧདརེ།༄ ༼གེ༽"
labels: documentation, enhancement
assignees: firewicca

---

I’m just going to send this message to everyone who don’t understand me and my instructions 

This will happens to everyone who is against me or tries to take my two 
Wife’s Sofia and Moa away from me
ever again

There is nothing to about trying to change this punishment! There are NO such way of doing that! And it is no such thing as regrets or some one else! I’m now putting the most strongest and dangerous ⚖️⚡️⚡️✨࿈Magོic࿇Spell࿈✨🩸🔥
ever།༄ ༴࿇གོཇངཉསདབ ཧདརེ།༄ ༼གེ༽
